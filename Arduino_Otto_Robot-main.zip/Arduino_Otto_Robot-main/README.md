# Arduino_Otto_Robot
This is the Otto robot code with library you can easily make this arduino robot. it is a simple arduino project.
Hello everyone,
I am vishal soni, This video is all about "How to build a arduino robot". this arduino robot called Otto robot. the otto robot has two legs it can do anything you want, Due to simplicity of this arduino project this is arduino tutorial for beginners. 

You can watch it on my youtube page and also on instructable all links given below.

_____________________________

youtube video :- https://youtu.be/xBAoARIPTug

____________________________

Instructables :- https://www.instructables.com/Otto-Robot-Arduino-Robot-Simple-Arduino-Robot/

___________________________

Hackster  :-  https://www.hackster.io/Vishalsoniindia/otto-robot-arduino-robot-simple-arduino-robot-428bfb

___________________________

[![alt text](https://img.youtube.com/vi/xBAoARIPTug/0.jpg)](https://youtu.be/xBAoARIPTug)


![alt text](https://content.instructables.com/FET/I187/KPMMJ20M/FETI187KPMMJ20M.jpg?auto=webp&frame=1&width=1024&height=1024&fit=bounds&md=1a2e1d5d0fae0aff152255fa77f0ede2)



![alt text](https://content.instructables.com/F0S/7ZW1/KPMMJG3J/F0S7ZW1KPMMJG3J.png?auto=webp&frame=1&width=1024&fit=bounds&md=7a392a7b041b8015e350b404f2dd5565)
